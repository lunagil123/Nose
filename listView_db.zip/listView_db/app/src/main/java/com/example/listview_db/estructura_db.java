package com.example.listview_db;

public class estructura_db {
    private estructura_db(){}
    public static final String TABLE_NAME = "peliculas";
    public static final String COLUMNID = "id";
    public static final String COLUMN1 = "nombre";
    public static final String COLUMN2 = "agno";
    public static final String COLUMN3 = "genero";
    public static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + estructura_db.TABLE_NAME + " (" +
                    estructura_db.COLUMNID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    estructura_db.COLUMN1 + " TEXT," +
                    estructura_db.COLUMN2 + " INTEGER," +
                    estructura_db.COLUMN3 + " TEXT)";
    public static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + estructura_db.TABLE_NAME;
}
