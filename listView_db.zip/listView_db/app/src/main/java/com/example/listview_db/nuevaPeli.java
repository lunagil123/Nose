package com.example.listview_db;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class nuevaPeli extends AppCompatActivity {
    EditText nombre,genero, agno;
    Button btn_save;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nueva_peli);
        nombre = findViewById(R.id.et_n_nombre);
        genero = findViewById(R.id.et_n_gen);
        agno = findViewById(R.id.et_n_agno);
        btn_save = findViewById(R.id.btn_save);
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveMovie();
            }
        });
    }
    @Override
    public void onBackPressed(){
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);
        finish();
    }
    public void saveMovie(){
        if(!nombre.getText().toString().isEmpty() && !genero.getText().toString().isEmpty() && !agno.getText().toString().isEmpty()){
            String pelicula, gen;
            int year;
            pelicula =  nombre.getText().toString();
            gen  = genero.getText().toString();
            year = Integer.parseInt(agno.getText().toString());

            final sqlHelper dbHelper = new sqlHelper(this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(estructura_db.COLUMN1, pelicula);
            values.put(estructura_db.COLUMN3, gen);
            values.put(estructura_db.COLUMN2, year);
            long newRowId = db.insert(estructura_db.TABLE_NAME, null, values);

            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
            finish();

        }else{
            Toast.makeText(getApplicationContext(),"Campos nulos!", Toast.LENGTH_LONG).show();
        }
    }

}