package com.example.listview_db;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class editPeli extends AppCompatActivity {
    int idMovie;
    EditText nombre, genero, agno;
    Button btnMod;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_peli);
        idMovie = getIntent().getExtras().getInt("idMovie");
        nombre = findViewById(R.id.et_e_nombre);
        genero = findViewById(R.id.et_e_gen);
        agno = findViewById(R.id.et_e_agno);
        btnMod = findViewById(R.id.btn_editar);
        consultar();
        btnMod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update();
            }
        });
    }
    @Override
    public void onBackPressed(){
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);
        finish();
    }
    public void consultar(){
        final sqlHelper dbHelper = new sqlHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                estructura_db.COLUMN1,
                estructura_db.COLUMN2,
                estructura_db.COLUMN3
        };
        String selection = estructura_db.COLUMNID + " = ?";
        String[] selectionArgs = { Integer.toString(idMovie) };

        try {
            Cursor cursor = db.query(
                    estructura_db.TABLE_NAME,   // The table to query
                    projection,             // The array of columns to return (pass null to get all)
                    selection,              // The columns for the WHERE clause
                    selectionArgs,          // The values for the WHERE clause
                    null,                   // don't group the rows
                    null,                   // don't filter by row groups
                    null                    // The sort order
            );
            cursor.moveToFirst();

            nombre.setText(cursor.getString(0));
            agno.setText(cursor.getString(1));
            genero.setText(cursor.getString(2));
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"sin registro", Toast.LENGTH_LONG).show();
        }
    }
    public void update(){
        if(!nombre.getText().toString().isEmpty() && !genero.getText().toString().isEmpty() && !agno.getText().toString().isEmpty()){
            String pelicula, gen;
            int year;
            pelicula =  nombre.getText().toString();
            gen  = genero.getText().toString();
            year = Integer.parseInt(agno.getText().toString());

            final sqlHelper dbHelper = new sqlHelper(this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(estructura_db.COLUMN1, pelicula);
            values.put(estructura_db.COLUMN2, year);
            values.put(estructura_db.COLUMN3, gen);

            String selection = estructura_db.COLUMNID + " LIKE ?";
            String[] selectionArgs = { Integer.toString(idMovie) };

            int count = db.update(
                    estructura_db.TABLE_NAME,
                    values,
                    selection,
                    selectionArgs);

            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
            finish();

        }else{
            Toast.makeText(getApplicationContext(),"Campos nulos!", Toast.LENGTH_LONG).show();
        }
    }

}