package com.example.listview_db;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button btn_nueva;
    int totalMovie;
    int idMovie;
    TextView tv_totalMovie;
    ArrayList<String> lista;
    ListView listado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_nueva =  findViewById(R.id.btn_nuevo);
        tv_totalMovie = findViewById(R.id.total);
        listado = findViewById(R.id.listView1);
        totalMovie = 0;
        idMovie = 0;

        lista = new ArrayList<String>();//inicializamos array list
        listaMovie();//consultamos lista de peliculas


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, lista);
        listado.setAdapter(adapter);
        listado.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                idMovie = position+1;
                goEditar();
            }
        });
        btn_nueva.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goNuevo();
            }
        });
    }
    public void goNuevo(){
        Intent i = new Intent(this, nuevaPeli.class);
        startActivity(i);
        finish();
    }

    public void goEditar(){
        Intent i = new Intent(this, editPeli.class);
        i.putExtra("idMovie",idMovie);
        startActivity(i);
        finish();
    }

    public void listaMovie(){
        final sqlHelper dbHelper = new sqlHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                estructura_db.COLUMNID,
                estructura_db.COLUMN1,
                estructura_db.COLUMN2,
                estructura_db.COLUMN3
        };
        try {
            Cursor cursor = db.query(
                    estructura_db.TABLE_NAME,   // The table to query
                    projection,             // The array of columns to return (pass null to get all)
                    null,              // The columns for the WHERE clause
                    null,          // The values for the WHERE clause
                    null,                   // don't group the rows
                    null,                   // don't filter by row groups
                    null                    // The sort order
            );
            while(cursor.moveToNext()){
                totalMovie++;
                lista.add(cursor.getString(1));//llenar array list
            }
            tv_totalMovie.setText("#"+totalMovie);
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"Sin registros!", Toast.LENGTH_LONG).show();
        }
    }

}